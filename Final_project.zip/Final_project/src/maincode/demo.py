from maincode.custom_functions import is_even, is_odd
if __name__ == '__main__':
    N = 1234567
    print(is_even(N))


